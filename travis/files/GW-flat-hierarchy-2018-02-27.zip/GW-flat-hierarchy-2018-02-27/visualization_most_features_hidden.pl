% File: visualization-most-features-hidden.pl

>>> phon.
pos <<< subj.
subj <<< spr.
spr <<< comps.
syn <<< head_dtr.
head_dtr <<< non_head_dtrs.

% -------- End of feature ordering ------------


%hidden_feat(non_head_dtrs).              % shown by the tree
%hidden_feat(head_dtr).

